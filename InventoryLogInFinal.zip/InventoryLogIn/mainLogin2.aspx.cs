﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class mainLogin2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Unnamed1_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("~/mainLogin.aspx");
    }

    protected void Unnamed2_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("~/mainLogin3.aspx");
    }
}