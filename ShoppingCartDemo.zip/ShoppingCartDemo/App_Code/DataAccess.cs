﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Data;
using System.Data.SqlClient;


/// <summary>
/// Summary description for DataAccess
/// </summary>
public class DataAccess
{

    public static string connect;


    static DataAccess()
    {
        //
        // TODO: Add constructor logic here
        //

        connect = WebConfigurationManager.ConnectionStrings["connect"].ConnectionString;

    }

    public static DataTable selectQuery(string query)
    {
        DataTable dt = new DataTable();
        SqlConnection con = new SqlConnection(connect);
        con.Open();
        SqlCommand cmd = new SqlCommand(query, con);
        dt.Load(cmd.ExecuteReader());


        con.Close();
        return dt;
    }

}